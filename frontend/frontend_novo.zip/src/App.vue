<template>
  <v-app>
    <RouterView />
  </v-app>
</template>

<script setup>
import { onMounted } from 'vue'
import { useAuthStore } from '@/store/auth'
const authStore = useAuthStore()

onMounted(async () => {
  const refreshed = await authStore.refreshToken()

  if (!refreshed) {
    await authStore.logout()
  }
})
</script>

<style lang="scss">
@use '@/assets/styles/global.scss' as *;
</style>
