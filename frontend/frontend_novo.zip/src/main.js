import { createApp } from 'vue'
import { createPinia } from 'pinia'
import { getCookie } from './utils/cookie'
import App from './App.vue'
import router from './router'
import vuetify from './plugins/vuetify'
import 'vuetify/styles'
import '@mdi/font/css/materialdesignicons.css'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate'
import { useAuthStore } from '@/store/auth'

const app = createApp(App)
const pinia = createPinia()
pinia.use(piniaPluginPersistedstate)

app.use(pinia)
app.use(router)
app.use(vuetify)

const authStore = useAuthStore(pinia)

// Só tenta renovar o token se ele existir
if (authStore.token) {
  authStore.refreshToken().finally(() => {
    router.isReady().then(() => {
      app.mount('#app')
    })
  })
} else {
  router.isReady().then(() => {
    app.mount('#app')
  })
}
