import { defineStore } from 'pinia'
import api from '@/services/api'

export const useCourseStore = defineStore('course', {
  state: () => ({
    userCourses: [], // Lista de cursos vinculados ao usuário logado
    currentCourse: null, // Curso atual carregado a partir do userCourseId
    loading: false, // Estado de carregamento para feedback visual
    error: null, // Armazena mensagens de erro
  }),

  // Persistência do estado entre sessões (localStorage)
  persist: {
    storage: localStorage,
    pick: ['userCourses', 'currentCourse'],
  },

  actions: {
    // Ação principal: busca os cursos do usuário e carrega o primeiro curso detalhado
    async fetchUserPrimaryCourse(userId) {
      this.startLoading()
      try {
        // Busca todos os cursos do usuário
        const response = await api.get(`/users/${userId}/courses`)
        this.userCourses = response.data
        console.log('Cursos recebidos:', this.userCourses)

        // Se houver ao menos um curso, obtém o primeiro user_course_id e carrega os detalhes
        if (Array.isArray(this.userCourses) && this.userCourses.length > 0) {
          const userCourseId = this.userCourses[0]?.user_course_id
          if (userCourseId) {
            await this.fetchUserCourseDetails(userCourseId)
          } else {
            throw new Error('ID do curso do usuário não encontrado.')
          }
        } else {
          throw new Error('Nenhum curso encontrado para este usuário.')
        }
      } catch (error) {
        this.handleError(error)
      } finally {
        this.stopLoading()
      }
    },

    // Busca os dados completos do curso a partir do user_course_id
    async fetchUserCourseDetails(userCourseId) {
      this.startLoading()
      try {
        const response = await api.get(`/course/${userCourseId}`)
        this.currentCourse = response.data
      } catch (error) {
        this.handleError(error)
      } finally {
        this.stopLoading()
      }
    },

    // Ativa estado de carregamento
    startLoading() {
      this.loading = true
      this.error = null
    },

    // Finaliza estado de carregamento
    stopLoading() {
      this.loading = false
    },

    // Captura e armazena mensagens de erro formatadas
    handleError(error) {
      console.error('Erro capturado:', error)
      this.error = this.formatError(error)
    },

    // Extrai a mensagem de erro para exibição legível
    formatError(error) {
      if (error?.response?.data?.message) {
        return error.response.data.message
      }
      if (error?.message) {
        return error.message
      }
      return 'Erro desconhecido. Tente novamente.'
    },
  },
})
