import { defineStore } from 'pinia'
import api from '@/services/api'

export const useUnitStore = defineStore('unit', {
  state: () => ({
    units: [],
    loading: false,
    error: null,
  }),

  persist: {
    storage: localStorage,
    pick: ['units'],
  },

  actions: {
    async fetchUnits(userCourseId) {
      this.startLoading()
      try {
        const response = await api.get(`/units/${userCourseId}`)
        this.units = response.data
      } catch (error) {
        this.handleError(error)
      } finally {
        this.stopLoading()
      }
    },

    startLoading() {
      this.loading = true
      this.error = null
    },

    stopLoading() {
      this.loading = false
    },

    handleError(error) {
      console.error('Erro capturado:', error)
      this.error = this.formatError(error)
    },

    formatError(error) {
      if (error?.response?.data?.message) {
        return error.response.data.message
      }
      if (error?.message) {
        return error.message
      }
      return 'Erro desconhecido. Tente novamente.'
    },
  },
})
