<template>
  <v-container>
    <!--Navegação provisória-->
    <router-link
      class="mx-auto mt-6"
      to="/units"
    >
      go to Units
    </router-link>
    <h1>Curso</h1>
    <div v-if="courseStore.loading">Carregando...</div>
    <div v-else-if="courseStore.error">Erro: {{ courseStore.error }}</div>
    <div v-else>
      <pre>{{ courseStore.currentCourse }}</pre>
    </div>
  </v-container>
</template>

<script setup>
import { onMounted } from 'vue'
import { useAuthStore } from '@/store/auth'
import { useCourseStore } from '@/store/course'

const authStore = useAuthStore()
const courseStore = useCourseStore()

onMounted(() => {
  const userId = authStore.user?.id
  if (userId) {
    courseStore.fetchUserPrimaryCourse(userId)
  }
})
</script>